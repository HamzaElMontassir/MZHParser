﻿Imports HexagonalParser.Domain.Enums

Namespace Entities

    ''' <summary>
    ''' Represents a configuration parameter entity
    ''' </summary>
    Public Class Setting
        Inherits BaseEntity

        Public Property Key As String

        Public Property Value As String

        Public Property Description As String

        Public Property IsActive As Boolean

        Public Property ConfigType As SettingType

        Public Overridable Property FileSettings As ICollection(Of FileSetting)

    End Class

End Namespace