﻿Namespace Entities
    ''' <summary>
    ''' Represents a base class
    ''' </summary>
    Public Class BaseEntity

        Public Property Id As Guid

        Public Property LastUpdated As DateTime

        Public Property UserIp As String

        Public Property UserName As String

    End Class

End Namespace