﻿Imports HexagonalParser.Domain.Enums

Namespace Entities

    ''' <summary>
    ''' Represents a file configuration entity
    ''' </summary>
    Public Class FileSetting
        Inherits BaseEntity

        Public Property ProductName As String

        Public Property Description As String

        Public Property InputFileExtension As FileExtension

        Public Property OutputFileExtension As FileExtension

        Public Property OutputStructure As String

        Public Property RecordFormat As String

        Public Property IsActive As Boolean

        Public Overridable Property Parameters As ICollection(Of Setting)

        Public Overridable Property FileProcessing As ICollection(Of FileProcessing)

    End Class

End Namespace