﻿Namespace Enums

    ''' <summary>
    ''' Enum for mapping types
    ''' </summary>
    Public Enum MappingType
        Transformation
        Validation
    End Enum

End Namespace