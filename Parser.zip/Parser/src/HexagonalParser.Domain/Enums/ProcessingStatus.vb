﻿Namespace Enums

    ''' <summary>
    ''' Enum for processing status
    ''' </summary>
    Public Enum ProcessingStatus
        Pending
        Processing
        Completed
        [Error]
    End Enum

End Namespace