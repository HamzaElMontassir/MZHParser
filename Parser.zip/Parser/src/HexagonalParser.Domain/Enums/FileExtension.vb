﻿Namespace Enums
    Public Enum FileExtension
        Json
        Xml
        Csv
        Txt
    End Enum
End Namespace