'-----------------------------------------------------------------------
' <copyright file="DataRow.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Namespace ValueObjects
    ''' <summary>
    '''     Represents a single row of data with dynamic column mapping.
    ''' </summary>
    Public Class DataRow
        ''' <summary>
        '''     The collection of column-value pairs for the row.
        ''' </summary>
        Public Property Columns As Dictionary(Of String, Object)

        ''' <summary>
        '''     Initializes a new instance of the DataRow class.
        ''' </summary>
        Public Sub New()
            Columns = New Dictionary(Of String, Object)()
        End Sub

        ''' <summary>
        '''     Sets the value for a specific column.
        ''' </summary>
        ''' <param name="columnName">The name of the column.</param>
        ''' <param name="value">The value to set.</param>
        Public Sub SetColumnValue(columnName As String, value As Object)
            If Columns.ContainsKey(columnName) Then
                Columns(columnName) = value
            Else
                Columns.Add(columnName, value)
            End If
        End Sub

        ''' <summary>
        '''     Gets the value of a specific column.
        ''' </summary>
        ''' <param name="columnName">The name of the column.</param>
        ''' <returns>The value of the column.</returns>
        Public Function GetColumnValue(columnName As String) As Object
            If Columns.ContainsKey(columnName) Then
                Return Columns(columnName)
            End If
            Return Nothing
        End Function

        ''' <summary>
        '''     Checks if a specific column exists in the row.
        ''' </summary>
        ''' <param name="columnName">The name of the column.</param>
        ''' <returns>True if the column exists, otherwise false.</returns>
        Public Function HasColumn(columnName As String) As Boolean
            Return Columns.ContainsKey(columnName)
        End Function
    End Class
End Namespace
