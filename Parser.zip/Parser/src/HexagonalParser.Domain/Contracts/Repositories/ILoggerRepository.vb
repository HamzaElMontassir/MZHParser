﻿Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    ''' <summary>
    '''     Interface for managing log-related operations.
    ''' </summary>
    Public Interface ILoggerRepository
        Inherits IBaseRepository(Of Logger)
    End Interface
End Namespace
