﻿Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface IFileProcessingRepository
        Inherits IBaseRepository(Of FileProcessing)
    End Interface
End Namespace
