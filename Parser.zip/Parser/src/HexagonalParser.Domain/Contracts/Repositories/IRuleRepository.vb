﻿'-----------------------------------------------------------------------
' <copyright file="IRuleRepository.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------

Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface IRuleRepository
        Inherits IBaseRepository(Of Rule)
    End Interface
End Namespace