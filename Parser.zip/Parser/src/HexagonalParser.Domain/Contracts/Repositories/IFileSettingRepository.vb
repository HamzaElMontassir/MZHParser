﻿Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface IFileSettingRepository
        Inherits IBaseRepository(Of FileSetting)
    End Interface
End Namespace
