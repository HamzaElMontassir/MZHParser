﻿' Defines a generic repository interface for interacting with data sources.
Imports System.Linq.Expressions
Imports System.Threading
Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface IBaseRepository(Of TEntity As BaseEntity)

        ' Retrieves all entities of type TEntity asynchronously.
        Function GetAllAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of ICollection(Of TEntity))

        Function FindAsync(predicate As Expression(Of Func(Of TEntity, Boolean)),
                           Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of ICollection(Of TEntity))

        ' Retrieves a specific entity by its unique identifier (GUID) asynchronously.
        Function GetByIdAsync(id As Guid, Optional cancellationToken As CancellationToken = Nothing) As Task(Of TEntity)

        ' Adds a new entity asynchronously.
        Function AddAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) As Task

        ' Updates an existing entity.  This operation is typically synchronous within the repository.
        Function UpdateAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) As Task

        ' Deletes an existing entity.  This operation is typically synchronous within the repository.
        Function DeleteAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) As Task

        ' Deletes an entity by its unique identifier asynchronously.
        Function DeleteByIdAsync(id As Guid, Optional cancellationToken As CancellationToken = Nothing) As Task

        ' Retrieves the total number of entities asynchronously.
        Function CountAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of Integer)

        ' Retrieves a paginated ICollection of entities asynchronously.
        Function GetPagedCollectionAsync(Of TKey)(
                                             pageNumber As Integer,
                                             pageSize As Integer,
                                             orderBy As Expression(Of Func(Of TEntity, TKey)),
                                             Optional ascending As Boolean = True,
                                             Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of ICollection(Of TEntity))
    End Interface
End NameSpace