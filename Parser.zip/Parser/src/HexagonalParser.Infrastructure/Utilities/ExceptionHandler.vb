﻿Imports System.Threading

Namespace Utilities
    Public Class ExceptionHandler
        ''' <summary>
        '''     Executes a function safely, handling any exceptions that occur.
        ''' </summary>
        ''' <typeparam name="TResult">The type of the result.</typeparam>
        ''' <param name="func">The function to execute.</param>
        ''' <param name="context">The context in which the function is executed.</param>
        ''' <param name="cancellationToken">The cancellation token.</param>
        ''' <param name="fallbackValue">The fallback value to return in case of an exception.</param>
        ''' <returns>The result of the function, or the fallback value if an exception occurs.</returns>
        Public Async Function ExecuteSafeAsync(Of TResult)(func As Func(Of Task(Of TResult)), context As String, cancellationToken As CancellationToken, fallbackValue As TResult) As Task(Of TResult)
            Try
                Return Await func()
            Catch ex As Exception
                ' Log the exception (you can replace this with your logging mechanism)
                Console.WriteLine($"Exception in {context}: {ex.Message}")
                Return fallbackValue
            End Try
        End Function

        ''' <summary>
        '''     Executes an action safely, handling any exceptions that occur.
        ''' </summary>
        ''' <param name="action">The action to execute.</param>
        ''' <param name="context">The context in which the action is executed.</param>
        ''' <param name="cancellationToken">The cancellation token.</param>
        ''' <returns>A task representing the asynchronous operation.</returns>
        Public Async Function ExecuteSafeAsync(action As Func(Of Task), context As String, cancellationToken As CancellationToken) As Task
            Try
                Await action()
            Catch ex As Exception
                ' Log the exception (you can replace this with your logging mechanism)
                Console.WriteLine($"Exception in {context}: {ex.Message}")
            End Try
        End Function
    End Class
End Namespace