﻿Imports HexagonalParser.Domain.Contracts.Logger
Imports Microsoft.Extensions.Caching.Memory
Imports Microsoft.Identity.Client.Cache
Imports System.Reflection
Imports System.Threading

Namespace Caching
    Public Class MemoryCacheAdapter(Of TKey, TValue)
        Implements IMemoryCachePort(Of TKey, TValue)
        Private ReadOnly _cache As IMemoryCache
        Private ReadOnly _config As CacheConfiguration
        Private ReadOnly _logger As ILogService

        Public Sub New(cache As IMemoryCache, config As CacheConfiguration, logger As ILogService)
            ArgumentNullException.ThrowIfNull(cache)
            ArgumentNullException.ThrowIfNull(config)
            ArgumentNullException.ThrowIfNull(logger)

            _cache = cache
            _config = config
            _logger = logger
        End Sub

        Public Async Function SetAsync(key As TKey,
                                       value As TValue,
                                       Optional expiration As TimeSpan? = Nothing,
                                       Optional isAbsoluteExpiration As Boolean = False,
                                       Optional options As MemoryCacheEntryOptions = Nothing,
                                       Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean) _
            Implements IMemoryCachePort(Of TKey, TValue).SetAsync
            Dim taskException As Task = Nothing
            Dim cacheOptions As MemoryCacheEntryOptions
            Try
                If key Is Nothing Then Throw New ArgumentNullException(NameOf(key))
                If value Is Nothing Then Throw New ArgumentNullException(NameOf(value))

                If _config Is Nothing Then Throw New ArgumentNullException(NameOf(_config))
                If _config.DefaultExpiration Is Nothing Then Throw New ArgumentNullException(NameOf(_config.DefaultExpiration))
                If isAbsoluteExpiration And _config.AbsoluteExpiration Is Nothing Then Throw New ArgumentNullException(NameOf(_config.AbsoluteExpiration))

                If isAbsoluteExpiration Then
                    cacheOptions = If(options, New MemoryCacheEntryOptions With {.SlidingExpiration = _config.AbsoluteExpiration})
                    Await _logger.LogInformationAsync(message:=$"Added '{key}' key with absolute expiration : {_config.AbsoluteExpiration}.",
                                                      cancellationToken:=cancellationToken)
                Else
                    cacheOptions = If(options, New MemoryCacheEntryOptions With {.SlidingExpiration = If(expiration, _config.DefaultExpiration)})
                    Await _logger.LogInformationAsync(message:=$"Added '{key}' key with expiration : {If(expiration, _config.DefaultExpiration)}.",
                                                      cancellationToken:=cancellationToken)
                End If

                Await Task.Run(Sub() _cache.Set(key, value, cacheOptions), cancellationToken)
                Await _logger.LogInformationAsync(message:=$"Adding the key '{key}' to the cache with the options: {cacheOptions}.",
                                                  cancellationToken:=cancellationToken)
            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:=ex.Message,
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
                Return False
            End If

            Return True
        End Function

        Public Async Function GetAsync(key As TKey,
                                       Optional cancellationToken As CancellationToken = Nothing) As Task(Of TValue) _
            Implements IMemoryCachePort(Of TKey, TValue).GetAsync
            Dim taskException As Task = Nothing
            Try
                If key Is Nothing Then Throw New ArgumentNullException(NameOf(key))

                Return Await Task.Run(Function()
                                          Dim value As Object = Nothing
                                          If _cache.TryGetValue(key, value) Then
                                              _logger.LogInformationAsync(message:=$"HIT cache for the key '{key}'.",
                                                                          cancellationToken:=cancellationToken)
                                              Return CType(value, TValue)
                                          End If

                                          _logger.LogWarningAsync(message:=$"MISS cache for the key'{key}'.",
                                                                  cancellationToken:=cancellationToken)
                                          Return Nothing
                                      End Function, cancellationToken)
            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:=ex.Message,
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
            End If

            Return Nothing
        End Function

        Public Async Function RemoveAsync(key As TKey,
                                          Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean) _
            Implements IMemoryCachePort(Of TKey, TValue).RemoveAsync
            Dim taskException As Task = Nothing
            Try
                If key Is Nothing Then Throw New ArgumentNullException(NameOf(key))

                Await Task.Run(Sub() _cache.Remove(key), cancellationToken)
                Await _logger.LogInformationAsync(message:=$"Removal of the key '{key}' from the cache.",
                                                  cancellationToken:=cancellationToken)
            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:=ex.Message,
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
                Return False
            End If

            Return True
        End Function

        Public Async Function ClearAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean) _
            Implements IMemoryCachePort(Of TKey, TValue).ClearAsync
            Dim taskException As Task = Nothing
            Try
                Await Task.Run(Sub()
                                   Dim cacheEntries = _cache.GetType().GetProperty("EntriesCollection", BindingFlags.NonPublic Or BindingFlags.Instance).GetValue(_cache)
                                   Dim clearMethod = _cache.GetType().GetMethod("Clear", BindingFlags.NonPublic Or BindingFlags.Instance)
                                   clearMethod.Invoke(_cache, Nothing)
                               End Sub, cancellationToken)
                Await _logger.LogInformationAsync(message:="Cache cleared successfully.",
                                                   cancellationToken:=cancellationToken)
            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:=ex.Message,
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
                Return False
            End If

            Return True
        End Function

        Public Async Function GetAllKeysAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of IEnumerable(Of TKey)) _
            Implements IMemoryCachePort(Of TKey, TValue).GetAllKeysAsync
            Dim taskException As Task = Nothing
            Dim KeyList As IEnumerable(Of TKey) = Nothing
            Try
                KeyList = CType(Await Task.Run(Function()
                                                   Dim cacheField = GetType(MemoryCache).GetProperty("EntriesCollection", BindingFlags.NonPublic Or BindingFlags.Instance)
                                                   Dim entries = CType(cacheField.GetValue(_cache), ICollection)
                                                   Dim keys = entries.Cast(Of Object)().Select(Function(entry)
                                                                                                   Dim keyProperty = entry.GetType().GetProperty("Key")
                                                                                                   Return keyProperty.GetValue(entry).ToString()
                                                                                               End Function).ToList()
                                                   _logger.LogInformationAsync(message:=$"Retrieving {keys.Count} cache keys.",
                                                                               cancellationToken:=cancellationToken)
                                                   Return keys
                                               End Function, cancellationToken), List(Of String))
            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:="Cache key retrieval failed.",
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
                Return Nothing
            End If
            Return KeyList

        End Function

        Public Async Function ExistsAsync(key As TKey, Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean) _
            Implements IMemoryCachePort(Of TKey, TValue).ExistsAsync
            Dim taskException As Task = Nothing
            Dim exists As Boolean = False
            Try
                If key Is Nothing Then Throw New ArgumentNullException(NameOf(key))
                Dim value = Await GetAsync(key, cancellationToken)
                exists = value IsNot Nothing

            Catch ex As Exception
                taskException = _logger.LogErrorAsync(message:=ex.Message,
                                                      exception:=ex,
                                                      cancellationToken:=cancellationToken)
            End Try

            If taskException Is Nothing Then
                Await taskException
                Return False
            End If

            Return exists
        End Function
    End Class
End Namespace