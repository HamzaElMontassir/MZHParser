﻿Namespace Caching
    ''' <summary>
    ''' Configuration settings for memory cache.
    ''' </summary>
    Public Class CacheConfiguration
        ''' <summary>
        ''' Default sliding expiration for cache entries.
        ''' </summary>
        Public Property DefaultExpiration As TimeSpan?

        ''' <summary>
        ''' Absolute expiration relative to now for cache entries.
        ''' </summary>
        Public Property AbsoluteExpiration As TimeSpan? = Nothing

        ''' <summary>
        ''' Maximum size limit for the cache, if applicable.
        ''' </summary>
        Public Property MaxSize As Long? = Nothing

        ''' <summary>
        ''' Enable or disable logging for cache operations.
        ''' </summary>
        Public Property EnableLogging As Boolean = True
    End Class
End Namespace
