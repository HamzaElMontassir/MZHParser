﻿Imports Microsoft.Extensions.Caching.Memory
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Logging

Namespace Caching
    Public Module CacheExtensions
        ''' <summary>
        ''' Ajoute et configure le cache mémoire avec des paramètres personnalisés.
        ''' </summary>
        ''' <param name="services">La collection de services.</param>
        ''' <param name="configuration">La configuration du cache.</param>
        ''' <returns>La collection de services mise à jour.</returns>
        <System.Runtime.CompilerServices.Extension>
        Public Function AddCustomMemoryCache(services As IServiceCollection, configuration As CacheConfiguration) As IServiceCollection
            If configuration Is Nothing Then
                Throw New ArgumentNullException(NameOf(configuration))
            End If

            services.AddMemoryCache(Sub(options)
                                         If configuration.MaxSize.HasValue Then
                                             options.SizeLimit = configuration.MaxSize
                                         End If
                                     End Sub)

            services.AddSingleton(Function(provider)
                                      Dim logger = provider.GetRequiredService(Of ILogger(Of MemoryCacheAdapter))()
                                      Return New MemoryCacheAdapter(provider.GetRequiredService(Of IMemoryCache), configuration, logger)
                                  End Function)

            If configuration.EnableLogging Then
                Dim logger = services.BuildServiceProvider().GetRequiredService(Of ILogger(Of MemoryCacheAdapter))()
                logger.LogInformation("MemoryCacheAdapter initialisé avec la configuration : {Config}", configuration)
            End If

            Return services
        End Function

        ''' <summary>
        ''' Configure dynamiquement les options d'entrée du cache.
        ''' </summary>
        ''' <param name="options">Les options d'entrée du cache.</param>
        ''' <param name="configuration">La configuration du cache.</param>
        <System.Runtime.CompilerServices.Extension>
        Public Sub ConfigureEntryOptions(options As MemoryCacheEntryOptions, configuration As CacheConfiguration)
            ArgumentNullException.ThrowIfNull(options)
            ArgumentNullException.ThrowIfNull(configuration)

            options.SlidingExpiration = configuration.DefaultExpiration

            If configuration.AbsoluteExpiration.HasValue Then
                options.AbsoluteExpirationRelativeToNow = configuration.AbsoluteExpiration.Value
            End If
        End Sub
    End Module
End Namespace