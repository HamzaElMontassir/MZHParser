﻿Imports System.Threading
Imports Microsoft.Extensions.Caching.Memory

Namespace Caching
    Public Interface IMemoryCachePort(Of TKey, TValue)

        Function SetAsync(key As TKey,
                          value As TValue,
                          Optional expiration As TimeSpan? = Nothing,
                          Optional isAbsoluteExpiration As Boolean = Nothing,
                          Optional options As MemoryCacheEntryOptions = Nothing,
                          Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean)

        Function GetAsync(key As TKey,
                          Optional cancellationToken As CancellationToken = Nothing) As Task(Of TValue)

        Function GetAllKeysAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of IEnumerable(Of TKey))

        Function RemoveAsync(key As TKey,
                             Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean)

        Function ClearAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean)

        Function ExistsAsync(key As TKey,
                             Optional cancellationToken As CancellationToken = Nothing) As Task(Of Boolean)
    End Interface
End Namespace
