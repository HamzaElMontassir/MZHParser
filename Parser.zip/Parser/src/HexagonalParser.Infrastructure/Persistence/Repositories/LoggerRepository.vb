﻿Imports HexagonalParser.Domain.Contracts.Repositories
Imports HexagonalParser.Domain.Entities
Imports HexagonalParser.Infrastructure.Persistence.DbContext

Namespace Persistence.Repositories
    ''' <summary>
    '''     Repository for managing logs in the database with caching and exception handling.
    ''' </summary>
    Public Class LoggerRepository
        Inherits BaseRepository(Of Logger)
        Implements ILoggerRepository

        ''' <summary>
        '''     Initializes a new instance of the <see cref="LoggerRepository" /> class.
        ''' </summary>
        ''' <param name="context">The database context.</param>
        ''' <param name="cacheProvider">The memory cache provider.</param>
        ''' <param name="exceptionHandler">The exception handler.</param>
        Public Sub New(context As HexagonalParserDbContext, cacheProvider As IMemoryCacheProvider(Of Guid, Logger),
                       exceptionHandler As ExceptionHandler)
            MyBase.New(context, cacheProvider, exceptionHandler)
        End Sub



    End Class
End Namespace
