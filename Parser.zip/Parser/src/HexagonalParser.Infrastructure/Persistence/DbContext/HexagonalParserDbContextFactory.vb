﻿Imports System.IO
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Design
Imports Microsoft.Extensions.Configuration

Namespace Persistence.DbContext
    ''' <summary>
    '''     Factory for creating instances of HexagonalParserDbContext at design time.
    ''' </summary>
    Public Class HexagonalParserDbContextFactory
        Implements IDesignTimeDbContextFactory(Of HexagonalParserDbContext)

        ''' <summary>
        '''     Creates a new instance of HexagonalParserDbContext.
        ''' </summary>
        ''' <param name="args">Arguments passed by the design-time tools.</param>
        ''' <returns>A new instance of HexagonalParserDbContext.</returns>
        Public Function CreateDbContext(args() As String) As HexagonalParserDbContext Implements IDesignTimeDbContextFactory(Of HexagonalParserDbContext).CreateDbContext
            Dim optionsBuilder = New DbContextOptionsBuilder(Of HexagonalParserDbContext)()

            ' Remplacez par la méthode appropriée pour obtenir la configuration
            Dim configuration = New ConfigurationBuilder() _
                .SetBasePath(Directory.GetCurrentDirectory()) _
                .AddJsonFile("appsettings.json") _
                .Build()

            optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"))
            Return New HexagonalParserDbContext(optionsBuilder.Options, configuration)
        End Function
    End Class
End Namespace