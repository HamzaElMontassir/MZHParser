﻿Imports HexagonalParser.Domain.Entities
Imports HexagonalParser.Infrastructure.Persistence.DbContext.Configurations
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration

Namespace Persistence.DbContext
    ''' <summary>
    '''     Database context for the Hexagonal Parser application.
    ''' </summary>
    Public Class HexagonalParserDbContext
        Inherits Microsoft.EntityFrameworkCore.DbContext

        Private ReadOnly _configuration As IConfiguration

        ''' <summary>
        '''     Initializes a new instance of the <see cref="HexagonalParserDbContext"/> class.
        ''' </summary>
        ''' <param name="options">The options to be used by a <see cref="DbContext"/>.</param>
        ''' <param name="configuration">The application configuration.</param>
        Public Sub New(options As DbContextOptions(Of HexagonalParserDbContext), configuration As IConfiguration)
            MyBase.New(options)
            _configuration = configuration
        End Sub

        ''' <summary>
        '''     Gets or sets the FilesProcessing DbSet.
        ''' </summary>
        Public Property FilesProcessing As DbSet(Of FileProcessing)

        ''' <summary>
        '''     Gets or sets the FilesSetting DbSet.
        ''' </summary>
        Public Property FilesSetting As DbSet(Of FileSetting)

        ''' <summary>
        '''     Gets or sets the Loggers DbSet.
        ''' </summary>
        Public Property Loggers As DbSet(Of Logger)

        ''' <summary>
        '''     Gets or sets the Mappings DbSet.
        ''' </summary>
        Public Property Mappings As DbSet(Of Mapping)

        ''' <summary>
        '''     Gets or sets the Rules DbSet.
        ''' </summary>
        Public Property Rules As DbSet(Of Rule)

        ''' <summary>
        '''     Gets or sets the Settings DbSet.
        ''' </summary>
        Public Property Settings As DbSet(Of Setting)

        ''' <summary>
        '''     Configures entities using configuration classes.
        ''' </summary>
        ''' <param name="modelBuilder">The ModelBuilder instance.</param>
        Protected Overrides Sub OnModelCreating(modelBuilder As ModelBuilder)
            ' Apply entity configurations
            modelBuilder.ApplyConfiguration(New FileProcessingConfiguration())
            modelBuilder.ApplyConfiguration(New FileSettingConfiguration())
            modelBuilder.ApplyConfiguration(New LoggerConfiguration())
            modelBuilder.ApplyConfiguration(New MappingConfiguration())
            modelBuilder.ApplyConfiguration(New RuleConfiguration())
            modelBuilder.ApplyConfiguration(New SettingConfiguration())

            MyBase.OnModelCreating(modelBuilder)
        End Sub

        ''' <summary>
        '''     Configures the database context options.
        ''' </summary>
        ''' <param name="optionsBuilder">The DbContextOptionsBuilder instance.</param>
        Protected Overrides Sub OnConfiguring(optionsBuilder As DbContextOptionsBuilder)
            MyBase.OnConfiguring(optionsBuilder)
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"))
        End Sub
    End Class
End Namespace