﻿'-----------------------------------------------------------------------
' <copyright file="SettingConfiguration.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations
    Public Class LoggerConfiguration
        Inherits BaseConfiguration(Of Logger)
        Implements IEntityTypeConfiguration(Of Logger)

        Public Sub New()
            MyBase.New("TB_OMKLogs")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of Logger)) _
            Implements IEntityTypeConfiguration(Of Logger).Configure

            MyBase.Configure(builder)
            builder.Property(Function(e) e.Level).IsRequired().HasMaxLength(50)
            builder.Property(Function(e) e.Category).IsRequired().HasMaxLength(100)
            builder.Property(Function(e) e.Message).IsRequired().HasMaxLength(Integer.MaxValue)
            builder.Property(Function(e) e.CorrelationId).IsRequired()
        End Sub
    End Class
End Namespace
