﻿Namespace Adapters.ExternalServices
    Public Class WebServiceAdapter
    
    End Class
End NameSpace