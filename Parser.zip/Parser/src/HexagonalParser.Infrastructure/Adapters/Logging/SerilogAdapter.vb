﻿Imports System.Threading
Imports System.Threading.Tasks
Imports HexagonalParser.Domain.Contracts.Logger
Imports Serilog
Imports Serilog.Events

Namespace Adapters.Logging
    Public Class SerilogAdapter
        Implements ILogService

        Private ReadOnly _logger As ILogger

        Public Sub New(logger As ILogger)
            ArgumentNullException.ThrowIfNull(logger)
            _logger = logger
        End Sub

        Public Function LogDebugAsync(message As String, Optional properties As IDictionary(Of String, Object) = Nothing, Optional cancellationToken As CancellationToken = Nothing) As Task Implements ILogService.LogDebugAsync
            If cancellationToken.IsCancellationRequested Then
                Return Task.FromCanceled(cancellationToken)
            End If
            _logger.Debug("Message: {Message}, Properties: {@Properties}", message, properties)
            Return Task.CompletedTask
        End Function

        Public Function LogInformationAsync(message As String, Optional properties As IDictionary(Of String, Object) = Nothing, Optional cancellationToken As CancellationToken = Nothing) As Task Implements ILogService.LogInformationAsync
            If cancellationToken.IsCancellationRequested Then
                Return Task.FromCanceled(cancellationToken)
            End If
            _logger.Information("Message: {Message}, Properties: {@Properties}", message, properties)
            Return Task.CompletedTask
        End Function

        Public Function LogWarningAsync(message As String, Optional properties As IDictionary(Of String, Object) = Nothing, Optional cancellationToken As CancellationToken = Nothing) As Task Implements ILogService.LogWarningAsync
            If cancellationToken.IsCancellationRequested Then
                Return Task.FromCanceled(cancellationToken)
            End If
            _logger.Warning("Message: {Message}, Properties: {@Properties}", message, properties)
            Return Task.CompletedTask
        End Function

        Public Function LogErrorAsync(message As String, Optional exception As Exception = Nothing, Optional properties As IDictionary(Of String, Object) = Nothing, Optional cancellationToken As CancellationToken = Nothing) As Task Implements ILogService.LogErrorAsync
            If cancellationToken.IsCancellationRequested Then
                Return Task.FromCanceled(cancellationToken)
            End If
            If exception IsNot Nothing Then
                _logger.Error(exception, "Message: {Message}, Properties: {@Properties}", message, properties)
            Else
                _logger.Error("Message: {Message}, Properties: {@Properties}", message, properties)
            End If
            Return Task.CompletedTask
        End Function

        Public Function LogFatalAsync(message As String, Optional exception As Exception = Nothing, Optional properties As IDictionary(Of String, Object) = Nothing, Optional cancellationToken As CancellationToken = Nothing) As Task Implements ILogService.LogFatalAsync
            If cancellationToken.IsCancellationRequested Then
                Return Task.FromCanceled(cancellationToken)
            End If
            If exception IsNot Nothing Then
                _logger.Fatal(exception, "Message: {Message}, Properties: {@Properties}", message, properties)
            Else
                _logger.Fatal("Message: {Message}, Properties: {@Properties}", message, properties)
            End If
            Return Task.CompletedTask
        End Function
    End Class
End Namespace