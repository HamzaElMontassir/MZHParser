﻿Imports Microsoft.Extensions.Configuration
Imports Serilog

Namespace Adapters.Logging

    ''' <summary>
    ''' Configuration for integrating Serilog with the application.
    ''' </summary>
    Public Module SerilogConfiguration

        ''' <summary>
        ''' Configures Serilog for the application.
        ''' </summary>
        ''' <param name="configuration">The application configuration.</param>
        ''' <param name="outputTemplate">Specifies the template for log messages.</param>
        ''' <param name="logFilePath">Path to the log file.</param>
        ''' <param name="logLevel">Minimum log level to capture.</param>
        Public Sub ConfigureSerilog(ByVal configuration As IConfiguration, ByVal outputTemplate As String, ByVal logFilePath As String, ByVal logLevel As Serilog.Events.LogEventLevel)
            ' Validate parameters
            If String.IsNullOrWhiteSpace(outputTemplate) Then
                Throw New ArgumentException("Output template cannot be empty.", NameOf(outputTemplate))
            End If

            If String.IsNullOrWhiteSpace(logFilePath) Then
                Throw New ArgumentException("Log file path cannot be empty.", NameOf(logFilePath))
            End If

            ' Get connection string from configuration
            Dim connectionString As String = configuration.GetConnectionString("DefaultConnection")
            If String.IsNullOrWhiteSpace(connectionString) Then
                Throw New ArgumentException("Connection string for database logging cannot be empty.")
            End If

            ' Initialize logger configuration
            Dim logger As LoggerConfiguration = New LoggerConfiguration()

            ' Enrich logs with contextual information
            logger.Enrich.FromLogContext()
            logger.Enrich.WithMachineName()
            logger.Enrich.WithThreadId()
            logger.Enrich.WithProcessId()
            logger.Enrich.WithProcessName()
            logger.Enrich.WithProperty("ApplicationName", "HexagonalParser")

            ' Configure minimum log level
            logger.MinimumLevel.Is(logLevel)

            ' Configure console sink
            ConfigureConsoleSink(logger, outputTemplate)

            ' Configure file sink
            ConfigureFileSink(logger, logFilePath, outputTemplate)

            ' Configure database sink
            ConfigureDatabaseSink(logger, connectionString, logLevel)

            ' Set the global logger
            Try
                Log.Logger = logger.CreateLogger()
            Catch ex As Exception
                Throw New InvalidOperationException("Failed to initialize Serilog logger.", ex)
            End Try
        End Sub

        ''' <summary>
        ''' Configures the console sink.
        ''' </summary>
        ''' <param name="logger">The logger configuration.</param>
        ''' <param name="outputTemplate">The output template for log messages.</param>
        Private Sub ConfigureConsoleSink(ByVal logger As LoggerConfiguration, ByVal outputTemplate As String)
            logger.WriteTo.Console(outputTemplate:=outputTemplate)
        End Sub

        ''' <summary>
        ''' Configures the file sink.
        ''' </summary>
        ''' <param name="logger">The logger configuration.</param>
        ''' <param name="logFilePath">The path to the log file.</param>
        ''' <param name="outputTemplate">The output template for log messages.</param>
        Private Sub ConfigureFileSink(ByVal logger As LoggerConfiguration, ByVal logFilePath As String, ByVal outputTemplate As String)
            If Not System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(logFilePath)) Then
                Throw New System.IO.DirectoryNotFoundException($"Log directory does not exist: {System.IO.Path.GetDirectoryName(logFilePath)}")
            End If

            logger.WriteTo.File(
                path:=logFilePath,
                outputTemplate:=outputTemplate,
                rollingInterval:=RollingInterval.Day,
                retainedFileCountLimit:=7
            )
        End Sub

        ''' <summary>
        ''' Configures the database sink.
        ''' </summary>
        ''' <param name="logger">The logger configuration.</param>
        ''' <param name="connectionString">The connection string for the database.</param>
        ''' <param name="logLevel">The minimum log level to capture.</param>
        Private Sub ConfigureDatabaseSink(ByVal logger As LoggerConfiguration, ByVal connectionString As String, ByVal logLevel As Serilog.Events.LogEventLevel)
            logger.WriteTo.MSSqlServer(
                connectionString:=connectionString,
                tableName:="TB_OMKLogs",
                autoCreateSqlTable:=True,
                restrictedToMinimumLevel:=logLevel
            )
        End Sub

        ''' <summary>
        ''' Disposes the Serilog logger.
        ''' </summary>
        Public Sub ShutdownLogger()
            If Log.Logger IsNot Nothing Then
                Log.CloseAndFlush()
            Else
                Throw New InvalidOperationException("Logger is not initialized. Unable to shutdown.")
            End If
        End Sub

    End Module

End Namespace