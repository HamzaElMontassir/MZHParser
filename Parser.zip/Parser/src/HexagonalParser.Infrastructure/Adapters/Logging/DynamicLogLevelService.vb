﻿Imports Serilog
Imports Serilog.Core
Imports Serilog.Events

Namespace Adapters.Logging

    Public Class DynamicLogLevelService
        Private ReadOnly _logLevelSwitch As LoggingLevelSwitch

        Public Sub New(levelSwitch As LoggingLevelSwitch)
            _logLevelSwitch = levelSwitch
        End Sub

        ''' <summary>
        ''' Gets the current log level.
        ''' </summary>
        ''' <returns>The current log level.</returns>
        Public Function GetCurrentLogLevel() As LogEventLevel
            Return _logLevelSwitch.MinimumLevel
        End Function

        ''' <summary>
        ''' Sets a new log level dynamically.
        ''' </summary>
        ''' <param name="newLogLevel">The new log level to set.</param>
        Public Sub SetLogLevel(ByVal newLogLevel As LogEventLevel)
            _logLevelSwitch.MinimumLevel = newLogLevel
        End Sub

        ''' <summary>
        ''' Applies the dynamic log level switch to the logger.
        ''' </summary>
        Public Sub ApplyDynamicLogLevel()
            Log.Logger = New LoggerConfiguration() _
                .MinimumLevel.ControlledBy(_logLevelSwitch) _
                .WriteTo.Console() _
                .CreateLogger()
        End Sub
    End Class

End Namespace