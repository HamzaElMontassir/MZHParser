﻿Namespace Adapters.Messaging

    ''' <summary>
    ''' Interface for retrieving email configuration from a data source.
    ''' </summary>
    Public Interface IEmailConfigService
        ''' <summary>
        ''' Retrieves the email configuration.
        ''' </summary>
        Function GetEmailConfiguration() As MessagingConfiguration
    End Interface

End Namespace