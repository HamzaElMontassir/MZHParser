﻿Imports System.Net
Imports System.Net.Mail
Imports HexagonalParser.Domain.Contracts.Logger

Namespace Adapters.Messaging

    ''' <summary>
    ''' Adapter for sending emails with configuration loaded from the database.
    ''' </summary>
    Public Class EmailAdapter

        Private ReadOnly _logger As ILogService
        Private ReadOnly _configService As IEmailConfigService

        ''' <summary>
        ''' Initializes a new instance of the <see cref="EmailAdapter"/> class.
        ''' </summary>
        ''' <param name="logger">Logger instance for logging operations.</param>
        ''' <param name="configService">Service to retrieve email configuration.</param>
        Public Sub New(logger As ILogService, configService As IEmailConfigService)
            _logger = logger
            _configService = configService
        End Sub

        ''' <summary>
        ''' Sends an email using the provided parameters.
        ''' </summary>
        ''' <param name="to">Recipient email address.</param>
        ''' <param name="subject">Email subject.</param>
        ''' <param name="body">Email body.</param>
        ''' <param name="attachments">Optional list of file paths for attachments.</param>
        Public Sub SendEmail([to] As String, subject As String, body As String, Optional attachments As List(Of String) = Nothing)
            Try
                ' Retrieve configuration from the database
                Dim config = _configService.GetEmailConfiguration()
                If config Is Nothing Then
                    Throw New InvalidOperationException("Email configuration could not be loaded from the database.")
                End If

                ' Validate parameters
                If String.IsNullOrWhiteSpace([to]) Then Throw New ArgumentException("Recipient email address is required.")
                If String.IsNullOrWhiteSpace(subject) Then Throw New ArgumentException("Email subject is required.")
                If String.IsNullOrWhiteSpace(body) Then Throw New ArgumentException("Email body is required.")

                ' Log email details
                _logger.LogInformationAsync($"Sending email to: {[to]}, Subject: {subject}")

                ' Create the email message
                Dim mailMessage = New MailMessage()
                mailMessage.From = New MailAddress(config.SenderEmail, config.SenderName)
                mailMessage.To.Add([to])
                mailMessage.Subject = subject
                mailMessage.Body = body
                mailMessage.IsBodyHtml = config.IsHtml

                ' Attach files if provided
                If attachments IsNot Nothing Then
                    For Each attachmentPath In attachments
                        mailMessage.Attachments.Add(New Attachment(attachmentPath))
                    Next
                End If

                ' Configure and send the email
                Using smtpClient As New SmtpClient(config.SmtpServer, config.SmtpPort)
                    smtpClient.Credentials = New NetworkCredential(config.SenderEmail, config.SenderPassword)
                    smtpClient.EnableSsl = config.EnableSsl
                    smtpClient.Send(mailMessage)
                End Using

                _logger.LogInformationAsync($"Email successfully sent to: {[to]}")
            Catch ex As Exception
                _logger.LogErrorAsync("Failed to send email.", ex)
                Throw
            End Try
        End Sub

    End Class

End Namespace
