﻿Imports Microsoft.Extensions.Configuration
Imports Microsoft.Extensions.DependencyInjection

Namespace Adapters.Messaging

    ''' <summary>
    ''' Provides extension methods for configuring email messaging services.
    ''' </summary>
    Public Module MessagingExtensions

        ''' <summary>
        ''' Registers the EmailAdapter and related messaging services in the DI container.
        ''' </summary>
        ''' <param name="services">The service collection to configure.</param>
        ''' <param name="configuration">The application configuration instance.</param>
        ''' <returns>The updated service collection.</returns>
        <System.Runtime.CompilerServices.Extension>
        Public Function AddMessagingServices(ByVal services As IServiceCollection, ByVal configuration As IConfiguration) As IServiceCollection
            Dim messagingConfig = New MessagingConfiguration()
            configuration.GetSection("Messaging").Bind(messagingConfig)
            services.AddSingleton(messagingConfig)
            services.AddSingleton(Of EmailAdapter)()
            Return services
        End Function

    End Module

End Namespace
