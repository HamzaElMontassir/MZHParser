﻿Namespace Adapters.Messaging

    ''' <summary>
    ''' Configuration settings for email messaging.
    ''' </summary>
    Public Class MessagingConfiguration

        ''' <summary>
        ''' Gets or sets the SMTP server address.
        ''' </summary>
        Public Property SmtpServer As String

        ''' <summary>
        ''' Gets or sets the SMTP server port.
        ''' </summary>
        Public Property SmtpPort As Integer

        ''' <summary>
        ''' Gets or sets the sender's email address.
        ''' </summary>
        Public Property SenderEmail As String

        ''' <summary>
        ''' Gets or sets the sender's name.
        ''' </summary>
        Public Property SenderName As String

        ''' <summary>
        ''' Gets or sets the sender's email password.
        ''' </summary>
        Public Property SenderPassword As String

        ''' <summary>
        ''' Gets or sets a value indicating whether SSL is enabled.
        ''' </summary>
        Public Property EnableSsl As Boolean

        ''' <summary>
        ''' Gets or sets a value indicating whether the email body is HTML.
        ''' </summary>
        Public Property IsHtml As Boolean

    End Class

End Namespace
