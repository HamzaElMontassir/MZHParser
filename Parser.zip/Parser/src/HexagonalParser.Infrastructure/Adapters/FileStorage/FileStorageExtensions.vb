﻿Imports Microsoft.Extensions.Configuration
Imports Microsoft.Extensions.DependencyInjection

Namespace Adapters.FileStorage

    ''' <summary>
    ''' Provides extension methods for configuring file storage services.
    ''' </summary>
    Public Module FileStorageExtensions

        ''' <summary>
        ''' Registers the LocalFileStorageAdapter in the service collection.
        ''' </summary>
        ''' <param name="services">The service collection to configure.</param>
        ''' <returns>The updated service collection.</returns>
        <System.Runtime.CompilerServices.Extension>
        Public Function AddFileStorage(ByVal services As IServiceCollection) As IServiceCollection
            services.AddSingleton(Of LocalFileStorageAdapter)()
            Return services
        End Function

        ''' <summary>
        ''' Configures file storage settings based on the application configuration.
        ''' </summary>
        ''' <param name="configuration">The application configuration.</param>
        ''' <returns>The configured file storage settings.</returns>
        Public Function GetFileStorageConfiguration(ByVal configuration As IConfiguration) As FileStorageConfiguration
            Dim config = New FileStorageConfiguration()
            configuration.GetSection("FileStorage").Bind(config)
            Return config
        End Function

    End Module

End Namespace
