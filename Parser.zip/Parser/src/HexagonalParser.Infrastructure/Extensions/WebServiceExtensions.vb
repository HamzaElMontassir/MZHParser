﻿Imports System.Runtime.CompilerServices
Imports HexagonalParser.Infrastructure.Extensions.Interfaces
Imports Microsoft.Extensions.DependencyInjection

Namespace Extensions
    Public Module WebServiceExtensions
        <Extension>
        Public Sub AddWebServiceAdapter(services As IServiceCollection)
            services.AddHttpClient(Of IWebServiceAdapter, WebServiceAdapter)()
        End Sub
    End Module
End Namespace
