﻿Namespace Extensions.Helpers
    Public Class RetryPolicyHelper
        Public Shared Async Function ExecuteWithRetryAsync(Of T)(func As Func(Of Task(Of T)), maxAttempts As Integer) As Task(Of T)
            Dim attempts = 0
            Do
                Try
                    attempts += 1
                    Return Await func()
                Catch ex As Exception
                    If attempts >= maxAttempts Then
                        Throw
                    End If
                End Try
            Loop
        End Function
    End Class
End Namespace
