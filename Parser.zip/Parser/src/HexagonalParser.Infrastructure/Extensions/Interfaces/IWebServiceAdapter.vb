﻿Imports HexagonalParser.Infrastructure.Extensions.Models

Namespace Extensions.Interfaces
    Public Interface IWebServiceAdapter
        Function CallServiceAsync(request As WebServiceRequest) As Task(Of WebServiceResponse)
    End Interface
End Namespace
