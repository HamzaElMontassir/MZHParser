﻿Imports Microsoft.Extensions.Caching.Memory
Imports Microsoft.Extensions.Logging
Imports System.Reflection
Imports HexagonalParser.Domain.Contracts.Logger

Namespace Caching
    Public interface IMemoryCacheAdapter
        Function SetAsync(Of T)(key As String, value As T, Optional options As MemoryCacheEntryOptions = Nothing) As Task
        Function GetAsync(Of T)(key As String) As Task(Of T)
        Function RemoveAsync(key As String) As Task
        Function ClearAsync() As Task
        Function SetWithAbsoluteExpirationAsync(Of T)(key As String, value As T, absoluteExpiration As TimeSpan) As Task
        Function GetOrCreateAsync(Of T)(key As String, factory As Func(Of T)) As Task(Of T)
        Function GetAllKeysAsync() As Task(Of IEnumerable(Of String))
    end interface

    Public Class MemoryCacheAdapter
        Implements IMemoryCacheAdapter
        Private ReadOnly _cache As IMemoryCache
        Private ReadOnly _config As CacheConfiguration
        Private ReadOnly _logger As ILogservice

        Public Sub New(cache As IMemoryCache, config As CacheConfiguration, logger As ILogservice)
            _cache = cache
            _config = config
            _logger = logger
        End Sub

        ' Méthode pour ajouter un élément au cache avec des options personnalisables
        Public Async Function SetAsync(Of T)(key As String, value As T, Optional options As MemoryCacheEntryOptions = Nothing) As Task Implements IMemoryCacheAdapter.SetAsync
            If String.IsNullOrWhiteSpace(key) Then
                Await _logger.LogErrorAsync("La clé de cache ne peut pas être nulle ou vide.")
                Throw New ArgumentException("La clé de cache ne peut pas être nulle ou vide.")
            End If

            Dim cacheOptions = If(options, New MemoryCacheEntryOptions With {
                .SlidingExpiration = _config.DefaultExpiration
            })

            Await Task.Run(Sub() _cache.Set(key, value, cacheOptions))
            Await _logger.LogInformationAsync($"Ajout de la clé '{key}' au cache avec les options : {cacheOptions}.")
        End Function

        ' Méthode pour récupérer un élément du cache
        Public Async Function GetAsync(Of T)(key As String) As Task(Of T) Implements IMemoryCacheAdapter.GetAsync
            If String.IsNullOrWhiteSpace(key) Then
                Await _logger.LogErrorAsync("La clé de cache ne peut pas être nulle ou vide.")
                Throw New ArgumentException("La clé de cache ne peut pas être nulle ou vide.")
            End If

            Return Await Task.Run(Function()
                                      Dim value As Object = Nothing
                                      If _cache.TryGetValue(key, value) Then
                                          _logger.LogInformationAsync($"Cache HIT pour la clé '{key}'.")
                                          Return CType(value, T)
                                      End If

                                      _logger.LogWarningAsync($"Cache MISS pour la clé '{key}'.")
                                      Return Nothing
                                  End Function)
        End Function

        ' Méthode pour supprimer un élément du cache
        Public Async Function RemoveAsync(key As String) As Task Implements IMemoryCacheAdapter.RemoveAsync
            If String.IsNullOrWhiteSpace(key) Then
                Await _logger.LogErrorAsync("La clé de cache ne peut pas être nulle ou vide.")
                Throw New ArgumentException("La clé de cache ne peut pas être nulle ou vide.")
            End If

            Await Task.Run(Sub() _cache.Remove(key))
            Await _logger.LogInformationAsync($"Suppression de la clé '{key}' du cache.")
        End Function

        ' Méthode pour vider le cache de manière asynchrone
        Public Async Function ClearAsync() As Task Implements IMemoryCacheAdapter.ClearAsync
            Try
                Await Task.Run(Sub()
                                   Dim cacheEntries = _cache.GetType().GetProperty("EntriesCollection", BindingFlags.NonPublic Or BindingFlags.Instance).GetValue(_cache)
                                   Dim clearMethod = _cache.GetType().GetMethod("Clear", BindingFlags.NonPublic Or BindingFlags.Instance)
                                   clearMethod.Invoke(_cache, Nothing)
                               End Sub)
                Await _logger.LogInformationAsync("Cache vidé avec succès.")
            Catch ex As Exception
                Await _logger.LogErrorAsync("Échec du vidage du cache.", ex)
                Throw
            End Try
        End Function

        ' Méthode pour ajouter un élément avec expiration absolue
        Public Async Function SetWithAbsoluteExpirationAsync(Of T)(key As String, value As T, absoluteExpiration As TimeSpan) As Task Implements IMemoryCacheAdapter.SetWithAbsoluteExpirationAsync
            If String.IsNullOrWhiteSpace(key) Then
                Await _logger.LogErrorAsync("La clé de cache ne peut pas être nulle ou vide.")
                Throw New ArgumentException("La clé de cache ne peut pas être nulle ou vide.")
            End If

            Await Task.Run(Sub()
                               _cache.Set(key, value, New MemoryCacheEntryOptions With {
                                   .AbsoluteExpirationRelativeToNow = absoluteExpiration
                               })
                           End Sub)
            Await _logger.LogInformationAsync($"Ajout de la clé '{key}' avec expiration absolue : {absoluteExpiration}.")
        End Function

        ' Méthode pour obtenir ou créer un élément
        Public Async Function GetOrCreateAsync(Of T)(key As String, factory As Func(Of T)) As Task(Of T) Implements IMemoryCacheAdapter.GetOrCreateAsync
            If String.IsNullOrWhiteSpace(key) Then
                Await _logger.LogErrorAsync("La clé de cache ne peut pas être nulle ou vide.")
                Throw New ArgumentException("La clé de cache ne peut pas être nulle ou vide.")
            End If

            Return Await Task.Run(Function()
                                      Return _cache.GetOrCreate(key, Function(entry)
                                                                         entry.SlidingExpiration = _config.DefaultExpiration
                                                                         _logger.LogInformationAsync($"Création d'une entrée de cache pour la clé '{key}'.")
                                                                         Return factory.Invoke()
                                                                     End Function)
                                  End Function)
        End Function

        ' Méthode pour lister toutes les clés du cache
        Public Async Function GetAllKeysAsync() As Task(Of IEnumerable(Of String)) Implements IMemoryCacheAdapter.GetAllKeysAsync
            Try
                Return Await Task.Run(Function()
                                          Dim cacheField = GetType(MemoryCache).GetProperty("EntriesCollection", BindingFlags.NonPublic Or BindingFlags.Instance)
                                          Dim entries = CType(cacheField.GetValue(_cache), ICollection)
                                          Dim keys = entries.Cast(Of Object)().Select(Function(entry)
                                                                                          Dim keyProperty = entry.GetType().GetProperty("Key")
                                                                                          Return keyProperty.GetValue(entry).ToString()
                                                                                      End Function).ToList()
                                          _logger.LogInformationAsync($"Récupération de {keys.Count} clés de cache.")
                                          Return keys
                                      End Function)
            Catch ex As Exception
                Await _logger.LogErrorAsync("Échec de la récupération des clés de cache.", ex)
                Throw
            End Try
        End Function
    End Class
End Namespace