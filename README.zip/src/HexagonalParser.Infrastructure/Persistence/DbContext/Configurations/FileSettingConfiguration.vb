﻿Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations

    ''' <summary>
    ''' Configurations for FileConfiguration entity
    ''' </summary>
    Public Class FileSettingConfiguration
        Inherits BaseConfiguration(Of FileSetting)
        Implements IEntityTypeConfiguration(Of FileSetting)

        Public Sub New()
            MyBase.New("TBP_OMKFileConfigurations")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of FileSetting)) _
            Implements IEntityTypeConfiguration(Of FileSetting).Configure

            MyBase.Configure(builder)
            builder.Property(Function(fc) fc.ProductName).IsRequired.HasMaxLength(255)
            builder.Property(Function(fc) fc.Description).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(fc) fc.InputFileExtension).IsRequired.HasMaxLength(5)
            builder.Property(Function(fc) fc.OutputFileExtension).IsRequired.HasMaxLength(5)
            builder.Property(Function(fc) fc.OutputStructure).IsRequired.HasMaxLength(Integer.MaxValue)
            builder.Property(Function(fc) fc.RecordFormat).HasMaxLength(255)
            builder.Property(Function(fc) fc.IsActive).IsRequired()

            builder.HasMany(Function(p) p.Parameters) _
                   .WithMany(Function(f) f.FileSettings) _
                   .UsingEntity(Of Dictionary(Of String, Object))(
                                       "TBP_OMKFileParameters",
                                       Function(fp) fp.HasOne(Of Setting) _
                                                      .WithMany() _
                                                      .HasForeignKey("ParameterId"),
                                       Function(fp) fp.HasOne(Of FileSetting) _
                                                      .WithMany() _
                                                      .HasForeignKey("FileId"))
        End Sub
    End Class

End Namespace