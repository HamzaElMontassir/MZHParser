﻿Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations

    ''' <summary>
    ''' Configurations for FileConfiguration entity
    ''' </summary>
    Public Class FileProcessingConfiguration
        Inherits BaseConfiguration(Of FileProcessing)
        Implements IEntityTypeConfiguration(Of FileProcessing)

        Public Sub New()
            MyBase.New("TB_OMKFileProcessing")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of FileProcessing)) _
            Implements IEntityTypeConfiguration(Of FileProcessing).Configure

            MyBase.Configure(builder)
            builder.Property(Function(fc) fc.InputFilePath).IsRequired.HasMaxLength(Integer.MaxValue)
            builder.Property(Function(fc) fc.OutputFilePath).IsRequired.HasMaxLength(Integer.MaxValue)
            builder.Property(Function(fc) fc.Status).IsRequired.HasMaxLength(50)
            builder.Property(Function(fc) fc.WorkFlowStatus).IsRequired.HasMaxLength(100)
            builder.Property(Function(fc) fc.RecordCount)
            builder.Property(Function(fc) fc.FileSize)
            builder.Property(Function(fc) fc.LastError).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(fc) fc.CorrelationId).IsRequired()
            builder.Property(Function(fc) fc.StartedAt).IsRequired()
            builder.Property(Function(fc) fc.ProcessedAt)

            builder.HasOne(Function(fc) fc.FileSetting) _
                   .WithMany(Function(fs) fs.FileProcessing) _
                   .HasForeignKey(Function(f) f.FileConfigurationId)
        End Sub
    End Class

End Namespace