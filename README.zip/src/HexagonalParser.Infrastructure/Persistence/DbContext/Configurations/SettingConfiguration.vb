﻿'-----------------------------------------------------------------------
' <copyright file="SettingConfiguration.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations
    ''' <summary>
    '''     Configures the Setting entity for the database.
    ''' </summary>
    Public Class SettingConfiguration
        Inherits BaseConfiguration(Of Setting)
        Implements IEntityTypeConfiguration(Of Setting)

        Public Sub New()
            MyBase.New("TBP_OMKParameters")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of Setting)) _
            Implements IEntityTypeConfiguration(Of Setting).Configure

            MyBase.Configure(builder)
            builder.Property(Function(e) e.Key).IsRequired().HasMaxLength(100)
            builder.Property(Function(e) e.Value).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(e) e.Description).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(e) e.IsActive).IsRequired()
            builder.Property(Function(e) e.ConfigType).IsRequired().HasMaxLength(50)
        End Sub
    End Class
End Namespace
