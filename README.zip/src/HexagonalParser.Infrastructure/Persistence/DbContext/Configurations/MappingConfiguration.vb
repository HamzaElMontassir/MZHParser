﻿Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations

    ''' <summary>
    ''' Configurations for Mapping entity
    ''' </summary>
    Public Class MappingConfiguration
        Inherits BaseConfiguration(Of Mapping)
        Implements IEntityTypeConfiguration(Of Mapping)

        Public Sub New()
            MyBase.New("TBP_OMKMappings")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of Mapping)) _
            Implements IEntityTypeConfiguration(Of Mapping).Configure

            MyBase.Configure(builder)
            builder.Property(Function(m) m.InputField).IsRequired.HasMaxLength(255)
            builder.Property(Function(m) m.OutputField).IsRequired.HasMaxLength(255)
            builder.Property(Function(m) m.Transformation).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(m) m.Description).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(m) m.MappingType).IsRequired.HasMaxLength(50)
            builder.Property(Function(m) m.FieldOrder).HasMaxLength(Integer.MaxValue)
            builder.Property(Function(m) m.IsActive).IsRequired.HasMaxLength(Integer.MaxValue)

            builder.HasMany(Function(m) m.Rules) _
                   .WithMany(Function(c) c.Mappings) _
                   .UsingEntity(Of Dictionary(Of String, Object))(
                                       "TBP_OMKMappingsRules",
                                       Function(mr) mr.HasOne(Of Rule) _
                                                      .WithMany() _
                                                      .HasForeignKey("RuleId"),
                                       Function(mr) mr.HasOne(Of Mapping) _
                                                      .WithMany() _
                                                      .HasForeignKey("MappingId"))
        End Sub
    End Class

End Namespace