﻿'-----------------------------------------------------------------------
' <copyright file="BaseConfiguration.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------

Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations
    Public Class BaseConfiguration(Of TEntity As BaseEntity)
        Implements IEntityTypeConfiguration(Of TEntity)

        Public Sub New(nameTable As String)
            ArgumentNullException.ThrowIfNull(nameTable)
            _nameTable = nameTable
        End Sub

        Public Sub Configure(builder As EntityTypeBuilder(Of TEntity)) _
            Implements IEntityTypeConfiguration(Of TEntity).Configure
            builder.ToTable(_nameTable)
            builder.HasKey(Function(e) e.Id)
            builder.Property(Function(e) e.LastUpdated).IsRequired()
            builder.Property(Function(e) e.UserIp).IsRequired.HasMaxLength(50)
            builder.Property(Function(e) e.UserName).IsRequired.HasMaxLength(255)
        End Sub

        Private ReadOnly Property _nameTable As String
    End Class
End Namespace
