﻿'-----------------------------------------------------------------------
' <copyright file="RuleConfiguration.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Entities
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.EntityFrameworkCore.Metadata.Builders

Namespace Persistence.DbContext.Configurations
    ''' <summary>
    '''     Configures the Rule entity for the database.
    ''' </summary>
    Public Class RuleConfiguration
        Inherits BaseConfiguration(Of Rule)
        Implements IEntityTypeConfiguration(Of Rule)

        Public Sub New()
            MyBase.New("TBP_OMKRules")
        End Sub

        Public Overloads Sub Configure(builder As EntityTypeBuilder(Of Rule)) _
            Implements IEntityTypeConfiguration(Of Rule).Configure

            MyBase.Configure(builder)
            builder.Property(Function(e) e.Name).IsRequired()
            builder.Property(Function(e) e.Condition).IsRequired.HasMaxLength(Integer.MaxValue)
            builder.Property(Function(e) e.Action).IsRequired.HasMaxLength(Integer.MaxValue)
            builder.Property(Function(e) e.IsActive).IsRequired()
            builder.Property(Function(e) e.ExecutionOrder)
        End Sub
    End Class
End Namespace
