Imports HexagonalParser.Domain.Contracts.Repositories
Imports HexagonalParser.Domain.Entities
Imports HexagonalParser.Infrastructure.Persistence.DbContext
Imports Microsoft.EntityFrameworkCore
Imports System.Collections.ObjectModel
Imports System.Linq.Expressions
Imports System.Threading
Imports HexagonalParser.Infrastructure.Utilities

Namespace Persistence.Repositories
    ''' <summary>
    '''     Generic repository providing CRUD operations with caching and exception handling.
    ''' </summary>
    ''' <typeparam name="TEntity">The type of the entity.</typeparam>
    Public Class BaseRepository(Of TEntity As BaseEntity)
        Implements IBaseRepository(Of TEntity)

        Protected ReadOnly Context As HexagonalParserDbContext
        Protected ReadOnly DbSet As DbSet(Of TEntity)
        Protected ReadOnly CacheProvider As IMemoryCacheProvider(Of Guid, TEntity)
        Protected ReadOnly ExceptionHandler As ExceptionHandler

        ''' <summary>
        '''     Initializes a new instance of the <see cref="BaseRepository" /> class.
        ''' </summary>
        ''' <param name="context">The database context.</param>
        ''' <param name="cacheProvider">The memory cache provider.</param>
        ''' <param name="exceptionHandler">The exception handler.</param>
        Public Sub New(context As HexagonalParserDbContext, cacheProvider As IMemoryCacheProvider(Of Guid, TEntity),
                       exceptionHandler As ExceptionHandler)
            Me.Context = context
            Me.DbSet = context.Set(Of TEntity)()
            Me.CacheProvider = cacheProvider
            Me.ExceptionHandler = exceptionHandler
        End Sub

        ''' <summary>
        '''     Retrieves all entities asynchronously.
        ''' </summary>
        Public Async Function GetAllAsync(Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of ICollection(Of TEntity)) _
            Implements IBaseRepository(Of TEntity).GetAllAsync
            Return Await ExceptionHandler.ExecuteSafeAsync(
                Async Function() Await DbSet.ToListAsync(cancellationToken),
                context:="BaseRepository.GetAllAsync",
                cancellationToken:=cancellationToken,
                fallbackValue:=New Collection(Of TEntity)())
        End Function

        ''' <summary>
        '''     Retrieves a single entity by its unique identifier asynchronously, with caching.
        ''' </summary>
        Public Async Function GetByIdAsync(id As Guid, Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of TEntity) _
            Implements IBaseRepository(Of TEntity).GetByIdAsync
            Return Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    Dim cachedEntity = Await CacheProvider.GetAsync(id, cancellationToken)
                    If cachedEntity IsNot Nothing Then Return cachedEntity

                    Dim entity = Await DbSet.FindAsync(New Object() {id}, cancellationToken)
                    If entity IsNot Nothing Then _
                                                              Await _
                                                              CacheProvider.SetAsync(id, entity,
                                                                                     TimeSpan.FromMinutes(5),
                                                                                     cancellationToken)
                    Return entity
                End Function,
                context:="BaseRepository.GetByIdAsync",
                cancellationToken:=cancellationToken,
                fallbackValue:=Nothing)
        End Function

        ''' <summary>
        '''     Retrieves entities matching a specified predicate asynchronously.
        ''' </summary>
        Public Async Function FindAsync(predicate As Expression(Of Func(Of TEntity, Boolean)),
                                        Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of ICollection(Of TEntity)) _
            Implements IBaseRepository(Of TEntity).FindAsync
            Return Await ExceptionHandler.ExecuteSafeAsync(
                Async Function() Await DbSet.Where(predicate).ToListAsync(cancellationToken),
                context:="BaseRepository.FindAsync",
                cancellationToken:=cancellationToken,
                fallbackValue:=New Collection(Of TEntity)())
        End Function

        ''' <summary>
        '''     Adds a new entity asynchronously, with caching.
        ''' </summary>
        Public Async Function AddAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) _
            As Task _
            Implements IBaseRepository(Of TEntity).AddAsync
            Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    Await DbSet.AddAsync(entity, cancellationToken)
                    ' Add to cache
                    Dim idProperty = entity.GetType().GetProperty("Id")
                    If idProperty IsNot Nothing Then
                        Dim id = CType(idProperty.GetValue(entity), Guid)
                        Await CacheProvider.SetAsync(id, entity, TimeSpan.FromMinutes(5), cancellationToken)
                    End If
                End Function,
                context:="BaseRepository.AddAsync",
                cancellationToken:=cancellationToken)
        End Function

        ''' <summary>
        '''     Updates an existing entity asynchronously, with caching.
        ''' </summary>
        Public Async Function UpdateAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) _
            As Task _
            Implements IBaseRepository(Of TEntity).UpdateAsync
            Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    DbSet.Attach(entity)
                    Context.Entry(entity).State = EntityState.Modified
                    ' Update cache
                    Dim idProperty = entity.GetType().GetProperty("Id")
                    If idProperty IsNot Nothing Then
                        Dim id = CType(idProperty.GetValue(entity), Guid)
                        Await CacheProvider.SetAsync(id, entity, TimeSpan.FromMinutes(5), cancellationToken)
                    End If
                End Function,
                context:="BaseRepository.UpdateAsync",
                cancellationToken:=cancellationToken)
        End Function

        ''' <summary>
        '''     Deletes an entity asynchronously, with cache removal.
        ''' </summary>
        Public Async Function DeleteAsync(entity As TEntity, Optional cancellationToken As CancellationToken = Nothing) _
            As Task _
            Implements IBaseRepository(Of TEntity).DeleteAsync
            Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    DbSet.Remove(entity)
                    ' Remove from cache
                    Dim idProperty = entity.GetType().GetProperty("Id")
                    If idProperty IsNot Nothing Then
                        Dim id = CType(idProperty.GetValue(entity), Guid)
                        Await CacheProvider.RemoveAsync(id, cancellationToken)
                    End If
                End Function,
                context:="BaseRepository.DeleteAsync",
                cancellationToken:=cancellationToken)
        End Function

        ''' <summary>
        '''     Deletes an entity by its unique identifier asynchronously, with cache removal.
        ''' </summary>
        Public Async Function DeleteByIdAsync(id As Guid, Optional cancellationToken As CancellationToken = Nothing) _
            As Task _
            Implements IBaseRepository(Of TEntity).DeleteByIdAsync
            Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    Dim entity = Await GetByIdAsync(id, cancellationToken)
                    If entity IsNot Nothing Then
                        DbSet.Remove(entity)
                        ' Remove from cache
                        Await CacheProvider.RemoveAsync(id, cancellationToken)
                    End If
                End Function,
                context:="BaseRepository.DeleteByIdAsync",
                cancellationToken:=cancellationToken)
        End Function

        ''' <summary>
        '''     Retrieves the total number of entities asynchronously.
        ''' </summary>
        Public Async Function CountAsync(Optional cancellationToken As CancellationToken = Nothing) As Task(Of Integer) _
            Implements IBaseRepository(Of TEntity).CountAsync
            Return Await ExceptionHandler.ExecuteSafeAsync(
                Async Function() Await DbSet.CountAsync(cancellationToken),
                context:="BaseRepository.CountAsync",
                cancellationToken:=cancellationToken,
                fallbackValue:=0)
        End Function

        ''' <summary>
        '''     Retrieves a paginated Collection of entities asynchronously.
        ''' </summary>
        Public Async Function GetPagedCollectionAsync(Of TKey)(
                                                          pageNumber As Integer,
                                                          pageSize As Integer,
                                                          orderBy As Expression(Of Func(Of TEntity, TKey)),
                                                          Optional ascending As Boolean = True,
                                                          Optional cancellationToken As CancellationToken = Nothing) _
            As Task(Of ICollection(Of TEntity)) _
            Implements IBaseRepository(Of TEntity).GetPagedCollectionAsync
            Return Await ExceptionHandler.ExecuteSafeAsync(
                Async Function()
                    Dim query = If(ascending,
                                   DbSet.OrderBy(orderBy),
                                   DbSet.OrderByDescending(orderBy))

                    Return Await query.Skip((pageNumber - 1) * pageSize).
                                                              Take(pageSize).
                                                              ToListAsync(cancellationToken)
                End Function,
                context:="BaseRepository.GetPagedCollectionAsync",
                cancellationToken:=cancellationToken,
                fallbackValue:=New Collection(Of TEntity)())
        End Function
    End Class
End Namespace
