'-----------------------------------------------------------------------
' <copyright file="SettingRepository.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Contracts.Repositories
Imports HexagonalParser.Domain.Entities
Imports HexagonalParser.Domain.Interfaces.Infrastructure.MemoryCache
Imports HexagonalParser.Domain.Models
Imports HexagonalParser.Infrastructure.Caching
Imports HexagonalParser.Infrastructure.Persistence.DbContext

Namespace Persistence.Repositories
    Public Class SettingRepository
        Inherits BaseRepository(Of Setting)
        Implements ISettingRepository

        ''' <summary>
        '''     Initializes a new instance of the <see cref="SettingRepository" /> class.
        ''' </summary>
        ''' <param name="context">The database context.</param>
        ''' <param name="cacheProvider">The memory cache provider.</param>
        ''' <param name="exceptionHandler">The exception handler.</param>
        Public Sub New(context As HexagonalParserDbContext, cacheProvider As IMemoryCacheProvider(Of Guid, Mapping),
                       exceptionHandler As ExceptionHandler)
            MyBase.New(context, cacheProvider, exceptionHandler)
        End Sub
    End Class
End Namespace
