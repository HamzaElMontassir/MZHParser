'-----------------------------------------------------------------------
' <copyright file="MappingRepository.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Contracts.Repositories
Imports HexagonalParser.Domain.Entities
Imports HexagonalParser.Infrastructure.Persistence.DbContext

Namespace Persistence.Repositories
    Public Class MappingRepository
        Inherits BaseRepository(Of Mapping)
        Implements IMappingRepository

        ''' <summary>
        '''     Initializes a new instance of the <see cref="MappingRepository" /> class.
        ''' </summary>
        ''' <param name="context">The database context.</param>
        ''' <param name="cacheProvider">The memory cache provider.</param>
        ''' <param name="exceptionHandler">The exception handler.</param>
        Public Sub New(context As HexagonalParserDbContext, cacheProvider As IMemoryCacheProvider(Of Guid, Mapping),
                       exceptionHandler As ExceptionHandler)
            MyBase.New(context, cacheProvider, exceptionHandler)
        End Sub
    End Class
End Namespace