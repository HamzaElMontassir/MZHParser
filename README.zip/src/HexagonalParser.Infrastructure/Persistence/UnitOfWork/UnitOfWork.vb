Imports HexagonalParser.Domain.Contracts.Repositories
Imports HexagonalParser.Domain.Interfaces.Infrastructure
Imports HexagonalParser.Domain.Interfaces.Infrastructure.MemoryCache
Imports HexagonalParser.Infrastructure.Caching
Imports HexagonalParser.Infrastructure.Persistence.DbContext
Imports HexagonalParser.Infrastructure.Persistence.Repositories
Imports System.Threading

Namespace Persistence.UnitOfWork
    ''' <summary>
    '''     UnitOfWork implementation for managing repositories, transactions, and shared services.
    ''' </summary>
    Public Class UnitOfWork
        Implements IUnitOfWork, IDisposable

        Private ReadOnly _context As HexagonalParserDbContext
        Private ReadOnly _cacheProvider As IMemoryCacheProvider(Of String, Object)
        Private ReadOnly _exceptionHandler As ExceptionHandler

        ' Repositories
        Private _settings As ISettingRepository
        Private _rules As IRuleRepository
        Private _mappings As IMappingRepository
        Private _logs As ILoggerRepository

        ' Flag to detect redundant calls to Dispose
        Private _disposed As Boolean = False

        ''' <summary>
        '''     Initializes a new instance of the <see cref="UnitOfWork" /> class.
        ''' </summary>
        ''' <param name="context">The DbContext instance to use.</param>
        ''' <param name="cacheProvider">The memory cache provider for caching entities.</param>
        ''' <param name="exceptionHandler">The exception handler for centralized error management.</param>
        Public Sub New(context As HexagonalParserDbContext, cacheProvider As IMemoryCacheProvider(Of String, Object),
                       exceptionHandler As ExceptionHandler)
            _context = context
            _cacheProvider = cacheProvider
            _exceptionHandler = exceptionHandler
        End Sub

        ''' <summary>
        '''     Gets the SettingRepository instance.
        ''' </summary>
        Public ReadOnly Property Settings As ISettingRepository Implements IUnitOfWork.Settings
            Get
                If _settings Is Nothing Then
                    _settings = New SettingRepository(_context, _cacheProvider, _exceptionHandler)
                End If
                Return _settings
            End Get
        End Property

        ''' <summary>
        '''     Gets the RuleRepository instance.
        ''' </summary>
        Public ReadOnly Property Rules As IRuleRepository Implements IUnitOfWork.Rules
            Get
                If _rules Is Nothing Then
                    _rules = New RuleRepository(_context, _cacheProvider, _exceptionHandler)
                End If
                Return _rules
            End Get
        End Property

        ''' <summary>
        '''     Gets the MappingRepository instance.
        ''' </summary>
        Public ReadOnly Property Mappings As IMappingRepository Implements IUnitOfWork.Mappings
            Get
                If _mappings Is Nothing Then
                    _mappings = New MappingRepository(_context, _cacheProvider, _exceptionHandler)
                End If
                Return _mappings
            End Get
        End Property

        ''' <summary>
        '''     Gets the LoggerRepository instance.
        ''' </summary>
        Public ReadOnly Property Logs As ILoggerRepository Implements IUnitOfWork.Logs
            Get
                If _logs Is Nothing Then
                    _logs = New LoggerRepository(_context, _cacheProvider, _exceptionHandler)
                End If
                Return _logs
            End Get
        End Property

        ''' <summary>
        '''     Saves all changes asynchronously.
        ''' </summary>
        ''' <param name="cancellationToken">A token to cancel the operation.</param>
        ''' <returns>An asynchronous task representing the operation.</returns>
        Public Async Function SaveChangesAsync(Optional cancellationToken As CancellationToken = Nothing) As Task _
            Implements IUnitOfWork.SaveChangesAsync
            Await _exceptionHandler.ExecuteSafeAsync(
                Async Function()
                    Await _context.SaveChangesAsync(cancellationToken)
                End Function,
                context:="UnitOfWork.SaveChangesAsync",
                cancellationToken:=cancellationToken)
        End Function

#Region "Dispose Management"

        ''' <summary>
        '''     Disposes of the resources used by the UnitOfWork.
        ''' </summary>
        Public Sub Dispose() Implements IDisposable.Dispose
            Dispose(disposing:=True)
            GC.SuppressFinalize(Me)
        End Sub

        ''' <summary>
        '''     Releases the resources used by the UnitOfWork.
        ''' </summary>
        ''' <param name="disposing">Indicates whether the method is called from Dispose (True) or a finalizer (False).</param>
        Protected Overridable Sub Dispose(disposing As Boolean)
            If Not _disposed Then
                If disposing Then
                    ' Dispose managed resources
                    _context.Dispose()
                End If
                _disposed = True
            End If
        End Sub

#End Region
    End Class
End Namespace
