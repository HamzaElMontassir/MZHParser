﻿Imports Microsoft.Extensions.DependencyInjection
Imports Serilog
Imports Serilog.Core
Imports Serilog.Events

Namespace Adapters.Logging
    ''' <summary>
    ''' Extension methods for setting up Serilog
    ''' </summary>
    Public Module LogExtensions
        ''' <summary>
        ''' Adds Serilog logging to the service collection.
        ''' </summary>
        ''' <param name="services">The service collection.</param>
        ''' <param name="configuration">The Serilog logger configuration action.</param>
        Public Sub AddSerilogLogging(services As IServiceCollection, configuration As Action(Of LoggerConfiguration))
            Dim logger = New LoggerConfiguration()
            configuration.Invoke(logger)
            Log.Logger = logger.CreateLogger()
            services.AddSingleton(Log.Logger)

            ' Register DynamicLogLevelService
            Dim levelSwitch As New LoggingLevelSwitch(LogEventLevel.Information)
            services.AddSingleton(New DynamicLogLevelService(levelSwitch))
        End Sub
    End Module
End Namespace