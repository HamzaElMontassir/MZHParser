﻿Imports HexagonalParser.Infrastructure.Persistence.DbContext
Imports Microsoft.EntityFrameworkCore
Imports Newtonsoft.Json

Namespace Adapters.Messaging

    ''' <summary>
    ''' Service to retrieve email configuration from the database.
    ''' </summary>
    Public Class DbEmailConfigService
        Implements IEmailConfigService

        Private ReadOnly _dbContext As HexagonalParserDbContext

        ''' <summary>
        ''' Initializes a new instance of the <see cref="DbEmailConfigService"/> class.
        ''' </summary>
        ''' <param name="dbContext">The database context.</param>
        Public Sub New(dbContext As HexagonalParserDbContext)
            _dbContext = dbContext
        End Sub

        ''' <summary>
        ''' Retrieves the email configuration from the database.
        ''' </summary>
        Public Function GetEmailConfiguration() As MessagingConfiguration Implements IEmailConfigService.GetEmailConfiguration
            ' Query the database for email configuration
            Dim config = _dbContext.Settings.FirstOrDefault(Function(c) c.[Key] = "EmailSettings")
            If config IsNot Nothing Then
                Return JsonConvert.DeserializeObject(Of MessagingConfiguration)(config.Value)
            End If

            Return Nothing
        End Function

    End Class

End Namespace
