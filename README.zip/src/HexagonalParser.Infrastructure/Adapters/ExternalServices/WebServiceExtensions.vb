﻿Namespace Adapters.ExternalServices
    Public Class WebServiceExtensions
    
    End Class
End NameSpace