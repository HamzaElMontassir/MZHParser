﻿Imports System.Linq
Imports HexagonalParser.Domain.Enums
Imports HexagonalParser.Enums

Namespace Adapters.FileStorage

    ''' <summary>
    ''' Represents the configuration settings for file storage operations.
    ''' </summary>
    Public Class FileStorageConfiguration

        ''' <summary>
        ''' Gets or sets the root directory for storing files.
        ''' </summary>
        Public Property RootDirectory As String

        ''' <summary>
        ''' Gets or sets the maximum allowable file size in bytes.
        ''' </summary>
        Public Property MaxFileSize As Long

        ''' <summary>
        ''' Gets or sets the allowed file extensions for upload.
        ''' </summary>
        Public Property AllowedFileExtensions As List(Of FileExtension)

        ''' <summary>
        ''' Initializes a new instance of the <see cref="FileStorageConfiguration"/> class.
        ''' Sets default values for certain properties.
        ''' </summary>
        Public Sub New()
            ' Set default values
            MaxFileSize = 10485760 ' Default to 10 MB
            AllowedFileExtensions = [Enum].GetValues(GetType(FileExtension)).Cast(Of FileExtension)().ToList()
        End Sub

        ''' <summary>
        ''' Validates the configuration settings for completeness and correctness.
        ''' </summary>
        ''' <exception cref="ArgumentException">Thrown if the configuration is invalid.</exception>
        Public Sub Validate()
            If String.IsNullOrWhiteSpace(RootDirectory) Then
                Throw New ArgumentException("RootDirectory must be specified in the file storage configuration.")
            End If

            If MaxFileSize <= 0 Then
                Throw New ArgumentException("MaxFileSize must be greater than zero.")
            End If

            If AllowedFileExtensions Is Nothing OrElse Not AllowedFileExtensions.Any() Then
                Throw New ArgumentException("At least one AllowedFileExtension must be specified.")
            End If
        End Sub

    End Class

End Namespace
