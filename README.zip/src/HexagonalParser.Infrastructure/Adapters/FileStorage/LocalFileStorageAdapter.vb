﻿Imports System.IO
Imports HexagonalParser.Domain.Contracts.Logger
Imports Serilog

Namespace Adapters.FileStorage

    ''' <summary>
    ''' Adapter for handling local file storage operations.
    ''' </summary>
    Public Class LocalFileStorageAdapter

        Private ReadOnly _logger As ILogService

        ''' <summary>
        ''' Initializes a new instance of the LocalFileStorageAdapter class.
        ''' </summary>
        ''' <param name="logger">The logger instance to use for logging operations.</param>
        Public Sub New(ByVal logger As ILogService)
            _logger = logger
        End Sub

        ''' <summary>
        ''' Validates the file path for compatibility across different operating systems.
        ''' </summary>
        ''' <param name="filePath">The file path to validate.</param>
        ''' <returns>True if the file path is valid, otherwise false.</returns>
        Public Function ValidateFilePath(ByVal filePath As String) As Boolean
            Try
                ' Ensure the file path is not null or empty
                If String.IsNullOrWhiteSpace(filePath) Then
                    _logger.LogErrorAsync("The file path cannot be null or empty.")
                    Throw New ArgumentException("The file path cannot be null or empty.")
                End If

                ' Ensure consistent directory separators
                filePath = filePath.Replace("/", System.IO.Path.DirectorySeparatorChar).Replace("\\", System.IO.Path.DirectorySeparatorChar)

                ' Check for invalid characters in the file path
                Dim invalidChars = System.IO.Path.GetInvalidPathChars()
                If filePath.Any(Function(c) invalidChars.Contains(c)) Then
                    ' Log invalid characters detected for debugging purposes
                    Dim invalidCharList = String.Join(", ", filePath.Where(Function(c) invalidChars.Contains(c)))
                    _logger.LogErrorAsync($"Invalid characters detected in file path: {invalidCharList}")
                    Throw New ArgumentException($"The file path contains invalid characters: {filePath}")
                End If

                ' Additional checks can be added for OS-specific validations if required

                Return True
            Catch ex As Exception
                ' Log or handle validation errors
                _logger.LogErrorAsync($"File path validation error: {ex.Message}", ex)
                Return False
            End Try
        End Function

        ''' <summary>
        ''' Saves a file to the specified location.
        ''' </summary>
        ''' <param name="filePath">The path where the file should be saved.</param>
        ''' <param name="data">The file data to save.</param>
        Public Sub SaveFile(ByVal filePath As String, ByVal data As Byte())
            If Not ValidateFilePath(filePath) Then
                _logger.LogErrorAsync("Invalid file path provided: {filePath}")
                Throw New ArgumentException("Invalid file path provided.")
            End If

            Try
                ' Create directory if it does not exist
                Dim directoryPath = System.IO.Path.GetDirectoryName(filePath)
                Try
                    If Not System.IO.Directory.Exists(directoryPath) Then
                        System.IO.Directory.CreateDirectory(directoryPath)
                        _logger.LogInformationAsync($"Directory created at {directoryPath}")
                    End If
                Catch dirEx As Exception
                    _logger.LogErrorAsync($"Failed to create directory at {directoryPath}", dirEx)
                    Throw New IOException($"Failed to create directory at {directoryPath}. Ensure the directory is accessible and permissions are correctly set.", dirEx)
                End Try

                ' Write the data to the file
                System.IO.File.WriteAllBytes(filePath, data)
                _logger.LogInformationAsync($"File saved successfully at {filePath}")
            Catch ex As Exception
                ' Handle exceptions during file save
                _logger.LogErrorAsync($"Failed to save the file at {filePath}", ex)
                Throw New IOException($"Failed to save the file at {filePath}. Directory: {System.IO.Path.GetDirectoryName(filePath)}", ex)
            End Try
        End Sub

        ''' <summary>
        ''' Reads a file from the specified location.
        ''' </summary>
        ''' <param name="filePath">The path of the file to read.</param>
        ''' <returns>The file data as a byte array.</returns>
        Public Function ReadFile(ByVal filePath As String) As Byte()
            If Not ValidateFilePath(filePath) Then
                _logger.LogErrorAsync("Invalid file path provided: {filePath}")
                Throw New ArgumentException("Invalid file path provided.")
            End If

            Try
                ' Ensure the file exists before reading
                If Not System.IO.File.Exists(filePath) Then
                    _logger.LogWarningAsync($"File not found at {filePath}")
                    Throw New FileNotFoundException($"The file at {filePath} does not exist.")
                End If

                Dim data = System.IO.File.ReadAllBytes(filePath)
                _logger.LogInformationAsync($"File read successfully from {filePath}")
                Return data
            Catch ex As Exception
                ' Handle exceptions during file read
                _logger.LogErrorAsync($"Failed to read the file at {filePath}", ex)
                Throw New IOException($"Failed to read the file at {filePath}", ex)
            End Try
        End Function

    End Class

End Namespace
