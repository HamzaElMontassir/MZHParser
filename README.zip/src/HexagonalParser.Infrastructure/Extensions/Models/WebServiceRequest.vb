﻿Namespace Extensions.Models
    Public Class WebServiceRequest
        Public Property Url As String
        Public Property Body As String
        Public Property ContentType As String = "application/json"
    End Class
End Namespace
