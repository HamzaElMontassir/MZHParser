﻿Imports System.Net

Namespace Extensions.Models
    Public Class WebServiceResponse
        Public Property StatusCode As HttpStatusCode
        Public Property Body As String
    End Class
End Namespace
