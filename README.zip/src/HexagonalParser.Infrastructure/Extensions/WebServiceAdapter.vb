﻿Imports System.Net.Http
Imports System.Text
Imports HexagonalParser.Domain.Contracts.Logger
Imports HexagonalParser.Infrastructure.Extensions.Interfaces
Imports HexagonalParser.Infrastructure.Extensions.Models

Namespace Extensions
    Public Class WebServiceAdapter
        Implements IWebServiceAdapter

        Private ReadOnly _httpClient As HttpClient
        Private ReadOnly _logger As ILogService

        Public Sub New(httpClient As HttpClient, logger As ILogService)
            _httpClient = httpClient
            _logger = logger
        End Sub

        Public Async Function CallServiceAsync(request As WebServiceRequest) As Task(Of WebServiceResponse) Implements IWebServiceAdapter.CallServiceAsync
            Try
                ' Validate request
                If request Is Nothing OrElse String.IsNullOrWhiteSpace(request.Url) Then
                    Throw New ArgumentException("Invalid request. URL cannot be null or empty.")
                End If

                ' Create HTTP request
                Dim httpRequest = New HttpRequestMessage(HttpMethod.Post, request.Url) With {
                    .Content = New StringContent(request.Body, Encoding.UTF8, request.ContentType)
                }

                ' Log the request
                _logger.LogInformationAsync($"Calling external service at {request.Url}")

                ' Send HTTP request
                Dim response = Await _httpClient.SendAsync(httpRequest)

                ' Handle response
                If response.IsSuccessStatusCode Then
                    Dim responseBody = Await response.Content.ReadAsStringAsync()
                    _logger.LogInformationAsync("Service call succeeded.")
                    Return New WebServiceResponse With {
                        .StatusCode = response.StatusCode,
                        .Body = responseBody
                    }
                Else
                    Dim errorDetails = Await response.Content.ReadAsStringAsync()
                    _logger.LogErrorAsync($"Service call failed: {errorDetails}")
                    Throw New HttpRequestException($"Service call failed with status code {response.StatusCode}")
                End If
            Catch ex As Exception
                _logger.LogErrorAsync("An error occurred while calling the external service.", ex)
                Throw
            End Try
        End Function
    End Class
End Namespace
