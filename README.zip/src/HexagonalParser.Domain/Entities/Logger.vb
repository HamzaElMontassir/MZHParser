﻿Imports Serilog.Events

Namespace Entities

    ''' <summary>
    ''' Represents a log entry entity
    ''' </summary>
    Public Class Logger
        Inherits BaseEntity

        Public Property Level As LogEventLevel

        Public Property Category As String

        Public Property Message As String

        Public Property CorrelationId As Guid?

    End Class

End Namespace