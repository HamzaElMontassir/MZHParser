﻿Imports HexagonalParser.Domain.Enums

Namespace Entities

    ''' <summary>
    ''' Represents a processed file entity
    ''' </summary>
    Public Class FileProcessing
        Inherits BaseEntity

        Public Property FileConfigurationId As Guid

        Public Property InputFilePath As String

        Public Property OutputFilePath As String

        Public Property Status As ProcessingStatus

        Public Property WorkFlowStatus As WorkFlowState

        Public Property RecordCount As Integer

        Public Property FileSize As Long

        Public Property LastError As String

        Public Property CorrelationId As Guid

        Public Property StartedAt As Date?

        Public Property ProcessedAt As Date?

        Public Overridable Property FileSetting As FileSetting

    End Class

End Namespace