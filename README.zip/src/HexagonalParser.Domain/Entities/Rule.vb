﻿Namespace Entities

    ''' <summary>
    ''' Represents a rule entity
    ''' </summary>
    Public Class Rule
        Inherits BaseEntity

        Public Property Name As String

        Public Property Condition As String

        Public Property Action As String

        Public Property IsActive As Boolean

        Public Property Priority As Integer

        Public Property ExecutionOrder As Integer

        Public Property Version As Integer

        Public Overridable Property Mappings As ICollection(Of Mapping)
    End Class

End Namespace