﻿
Imports HexagonalParser.Domain.Enums

Namespace Entities

    ''' <summary>
    ''' Represents a mapping entity
    ''' </summary>
    Public Class Mapping
        Inherits BaseEntity

        Public Property InputField As String

        Public Property OutputField As String

        Public Property Transformation As String

        Public Property Description As String

        Public Property MappingType As MappingType

        Public Property FileId As Guid

        Public Property FieldOrder As Integer

        Public Property IsActive As Boolean

        Public Overridable Property Rules As ICollection(Of Rule)

        Public Overridable Property FileSetting As FileSetting

    End Class

End Namespace