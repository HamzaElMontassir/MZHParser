﻿Namespace Enums
    Public Enum SettingType
        System
        User
        Application
    End Enum
End Namespace