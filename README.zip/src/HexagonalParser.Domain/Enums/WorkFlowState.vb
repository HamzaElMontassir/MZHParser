﻿Namespace Enums

    ''' <summary>
    ''' Enum for workflow status
    ''' </summary>
    Public Enum WorkFlowState
        LoadFile
        ValidateFile
        ProcessMappings
        GenerateOutput
        Completed
        [Error]
    End Enum

End Namespace