﻿'-----------------------------------------------------------------------
' <copyright file="IMappingRepository.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface IMappingRepository
        Inherits IBaseRepository(Of Mapping)
    End Interface
End Namespace