﻿'-----------------------------------------------------------------------
' <copyright file="ISettingRepository.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports HexagonalParser.Domain.Entities

Namespace Contracts.Repositories
    Public Interface ISettingRepository
        Inherits IBaseRepository(Of Setting)
    End Interface
End Namespace