﻿'-----------------------------------------------------------------------
' <copyright file="ILogger.vb" company="Mizuho of Paris">
'     Author:  H. EL MONTASSIR
'     Copyright (c) . All rights reserved.
' </copyright>
'-----------------------------------------------------------------------
Imports System.Threading
Imports Serilog

Namespace Contracts.Logger
    Public Interface ILogService 
        Inherits ILogger

        Function LogDebugAsync(message As String,
                               Optional properties As IDictionary(Of String, Object) = Nothing, 
                               Optional cancellationToken As CancellationToken = Nothing) As Task

        Function LogInformationAsync(message As String,
                                     Optional properties As IDictionary(Of String, Object) = Nothing, 
                                     Optional cancellationToken As CancellationToken = Nothing) As Task

        Function LogWarningAsync(message As String,
                                 Optional properties As IDictionary(Of String, Object) = Nothing, 
                                 Optional cancellationToken As CancellationToken = Nothing) As Task

        Function LogErrorAsync(message As String,
                          Optional exception As Exception = Nothing,
                          Optional properties As IDictionary(Of String, Object) = Nothing, 
                          Optional cancellationToken As CancellationToken = Nothing) As Task

        Function LogFatalAsync(message As String,
                               Optional exception As Exception = Nothing,
                               Optional properties As IDictionary(Of String, Object) = Nothing, 
                               Optional cancellationToken As CancellationToken = Nothing) As Task
    End Interface
End Namespace
